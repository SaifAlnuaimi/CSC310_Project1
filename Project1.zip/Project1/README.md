# Project 1
# The requirement to run these program is must use Python3

# Radix Sort
This is program use the radix sort algorithm to sort the list [35, 53, 55, 33,52, 32, 25]
All code implemented in file "radixSort.py"

To run it:
Linux:
Open terminal and enter this command:
Python3 radixSort.py

Windown:
Open cmd and enter the command:
Py -3 radixSort.py


# Postfix evaluation
This program use stack to evaluation for an expression in Postfix.
The example of post fix expression: 52+83-*4/

This program implemented in file evalPostfix.py
This program will need file input name "data.txt". This input file contain list of postfix expressions
Below is example of data.txt:
(10)28*+3-
52+83-*4/
53+82-*

To run this program, put the file data.txt same location with file evalPostfix.py and use the command below:
Linux:
Open terminal and enter this command:
Python3 evalPostfix.py

Windown:
Open cmd and enter the command:
Py -3 evalPostfix.py

